#!/usr/bin/perl -w

use strict;
use FileHandle;
#use Statistics::RankCorrelation;

unless($#ARGV == 1 || $#ARGV == 3){
    die "usage: $0 [id2P.txt] [id2Y.txt] (w*.txt) (C)\n";
}

require "/home/terai/script/basic.pl";

my $R = 0;
if(defined $ARGV[3]){
    $R = &calcRegTerm($ARGV[2], $ARGV[3]);
#    $R = &calcExpRegTerm($ARGV[2], $ARGV[3]);
#    $R = &calcShareTerm($ARGV[2], $ARGV[3]);
}

my $id2Pni_href = &readPni($ARGV[0]);
my %id2Y       = readHash($ARGV[1]);

my (@x, @y);
foreach my $id (keys %id2Y){
    next if($id2Pni_href->{$id} eq "NA");
    push(@x, $id2Y{$id});
    push(@y, $id2Pni_href->{$id});
}

my $diff_flg = 0;
{
    my $tmp = $x[0];
    foreach my $v (@x){
	if($tmp != $v){
	    $diff_flg = 1;
	    last;
	}
    }
}

my $rho = "NA";
my $cor = "NA";
if($diff_flg){
    #my $c = Statistics::RankCorrelation->new(\@x, \@y);
    #$rho = $c->spearman;

    $cor = correlation(\@x, \@y);
}

# ２乗誤差
my $e;
for(my $i = 0; $i <= $#x; $i++){
    $e += ($x[$i] - $y[$i])**2;
}

my $O = $e + $R;

print STDERR "Spearman:$rho, Pearson:$cor, SSE:$e, OBJ:$O\n";
print "Spearman:$rho, Pearson:$cor, SSE:$e, OBJ:$O\n";

sub calcExpRegTerm{
    my $r;
    
    my ($w_file, $c) = @_;
    
    my %w = &readW($w_file);
    
    for(my $i = 1; $i <= $w{L}; $i++){
	$r += exp($c*$w{wi}[$i]);
    }

#    for(my $i = 1; $i <= $w{L}; $i++){
#	$r += exp($w{wi}[$i]**2);
#    }
    
    return $r;
}

sub calcRegTerm{
    my $r;
    
    my ($w_file, $c) = @_;
    
    my %w = &readW($w_file);
    
#    $r += $w{wa} ** 2; # wb, wiを学習する
#    $r += exp($w{wb}) ** 2;
#    $r += $w{wb} ** 2; # wiのみ学習する
    
#    for(my $i = 1; $i <= $w{L}; $i++){
    for(my $i = 0; $i <= $w{L}; $i++){
	$r += $w{wi}[$i] ** 2;
    }
    
    return $c * $r;
}

sub calcShareTerm{
    my $r;
    
    my ($w_file, $c) = @_;
    
    my %w = &readW($w_file);
    
    for(my $i = 1; $i < $w{L}; $i++){
	$r += ($w{wi}[$i] - $w{wi}[$i+1]) ** 2;
    }
    
    return $c * $r;
}


sub readW{
    my %h;

    my $max_pos = -1;
    my $fh = new FileHandle($_[0]) || die "Can't open $_[0]:$!\n";
    while(<$fh>){
        chomp;

        if(/^(w[ab])/){
            my ($name, $val) = split /\t/;
            $h{$name} = $val;
        }
        elsif(/^w(\d+)/){
            my $pos = $1;
            my ($name, $val) = split /\t/;
            $h{wi}[$pos] = $val;
            $max_pos = $pos if($pos > $max_pos);
        }
        else{
            die "Unexpected line ($_)\n";
        }
    }
    $fh->close();

    $h{L} = $max_pos;

    return %h;
}


sub readPni{
    my %h;

    my $fh = new FileHandle($_[0]) || die;
    while(<$fh>){
        chomp;
        my @a = split /\t/;
        my ($id, $Pni, $Pfi) = ($a[0], $a[1], $a[2]);
        $h{$id} = $Pni;

    }
    $fh->close();

    return \%h;
}

# -*- coding: utf-8 -*-

import sys
sys.path.append("/wdir/common")
import basic
import numpy as np

args = sys.argv

if len(args) != 5:
    print("usage: {0} [act.txt] [id2prof.txt] [rrna len] [sd len]".format(__file__))
    exit(0)
    
xlen = int(args[3])
ylen = int(args[4])

def main():
    id2prof = readProf(args[2])
    
    id2act = basic.readHash(args[1])
    ids = id2prof.keys()
    id2Nact = normAct(id2act, ids)
    
    names_str = makeNames(xlen, ylen)
    print ("id\tact\t{0}".format(names_str))
    
    for id in id2prof:
        items = []
        items.append(id)
        items.append(str(id2Nact[id]))
        for i in range(len(id2prof[id])):
            #print(id2prof[id][i])
            items.append(id2prof[id][i])
        items_str = "\t".join(items)
        print(items_str)

def makeNames(xl, yl):
    len = xl * yl + (xl + yl) * 3
    n = []
    for i in range(len):
        n.append("f" + str(i))

    return "\t".join(n)
    
def normAct(id2a, ids):
    values = []
    for id  in ids:
        values.append(float(id2a[id]))

    values.sort()
    #for v in values:
    #    print(v)
    max = values[-1]
    min = values[0]

    d = {}
    for id in ids:
        d[id] = (float(id2a[id]) - min)/(max - min)

    # ここでゼロノーマライズを行う。
    #print(d.values())
    mean = np.mean(list(d.values()))
    
    for id in ids:
        d[id] = d[id] - mean

    return d
        
def readProf(fname):
    d = {}
    with open(fname, 'r') as fh:
        for line in fh.readlines():
            line = line.strip()
            vals = line.split("\t")
            d[vals[0]] = vals[1:]
    
    return d



main()

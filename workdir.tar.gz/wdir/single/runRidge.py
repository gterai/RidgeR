# -*- coding: utf-8 -*-

import sys
import pandas as pd
import numpy as np
#import math

args = sys.argv

if(len(args) != 4):
    print("usage: {0} [fv.txt] [alpha] [out file name]".format(__file__))
    exit(0)

data_df = pd.read_table(args[1]) 
#print(data_df)

fnames = data_df.columns[2:]
#print(fnames)

X = data_df[fnames].values 
Y = data_df['act'].values 
#sse = np.mean(Y**2)
#Sdata = np.mean(np.abs(Y))
#Sdata = np.mean(Y)

#from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

alp = args[2]
ridge = Ridge(alpha=float(alp),fit_intercept=False).fit(X, Y)

out_name = args[3]
with open(out_name, mode='w') as f:
    f.write("wa\t0\n")
    f.write("wb\t1\n")
    
    for i in range(len(ridge.coef_)):
        f.write("w{0}\t{1}\n".format(i,ridge.coef_[i]))
        
    Y2 = ridge.predict(X)
    from scipy.stats import pearsonr
    cor = pearsonr(Y, Y2)

    #    print(alp, cor, ridge.intercept_, file=sys.stderr)

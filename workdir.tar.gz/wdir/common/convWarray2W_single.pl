#!/usr/bin/perl -w

use strict;

unless($#ARGV == 0){
    die "usage: $0 [w.txt]\n";
}

my $nType = 6;

# read W
my @W;
open(FH, $ARGV[0]) || die;
<FH>; 
<FH>; 
while(<FH>){
    chomp;
    
    my ($w, $val) = split /\t/;
    if($w !~ /^w(\d+)$/){
	die "Unexpected format of weights ($w)\n";
    }
    
    my $idx = $1;
    $W[$idx] = $val;
    
}
close(FH);

# get seqence length
my $seqlen;
{
    my $nw = scalar @W;
    if($nw % $nType != 0){
	die "The number of parameter is not multiple of $nType.\n";
    }
    else{
	$seqlen = $nw/$nType;
    }
}

# type 0 = dspL
# type 1 = dspR
# type 2 = hairpin
# type 3 = bulge
# type 4 = internal
# type 5 = external
my @f_type_table = ("wL", "wR", "wH", "wB", "wI", "wE");

#my (@wL, @wR, @wH, @wB, @wI, @wE);
for(my $i = 0; $i <= $#W; $i++){
    
    my $pos    = $i % $seqlen;
    my $f_type = $f_type_table[int($i/$seqlen)];
    
    print "$f_type" . "_$pos\t$W[$i]\n";
    
}



#!/usr/bin/perl -w

use strict;
#use File::Basename;
use FindBin;

#my $ScriptDir = dirname $0;
my $ScriptDir = $FindBin::Bin;

unless($#ARGV == 2){
    die "usage :$0 [*.fa] [name(prefix)] [num. divide]\n";
}

require "$ScriptDir/getEachSize.pl";
require "$ScriptDir/basic.pl";

my @bin;
{
    my $n;
    open(FA, $ARGV[0]) || die;
    while(<FA>){
	$n++ if(/^>/);
    }
    close(FA);
    @bin = getEachSize($n, $ARGV[2]); 
}

print "@bin\n";

my $fn = 0;
my $i  = 0;
{
    open(FA, $ARGV[0]) || die;
    open(OUT, ">$ARGV[1].$fn") || die;
    while(<FA>){
	
	if(/^>/){
	    $i++;
	}
	
	if($fn < $#bin && $i - 1 == $bin[$fn]){
	    $fn++;
	    open(OUT, ">$ARGV[1].$fn") || die;
	    $i = 1;
	}
	
	print OUT;
	
    }
    close(FA);
    
}


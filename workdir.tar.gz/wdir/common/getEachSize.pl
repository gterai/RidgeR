#!/usr/bin/perl -w

#@bin = &getEachSize_unif(215, 100);
#print "@bin\n";

sub getEachSize($$){
    my $num = $_[0];
    my $div = $_[1];
    
    my $size = int($num/$div);
    my $residual = $num - ($size * $div);
    
    my @bin;
    for(my $i = 0; $i < $div; $i++){
	if($residual > 0){
	    $bin[$i] = $size + 1;
	    $residual--;
	}
	else{
	    $bin[$i] = $size;
	}
    }
    
    if($residual != 0){
	die "\$resudual should be zero here.\n";
    }
    
    return @bin;
    
}

sub divideEachSize($$){
    my $aref = $_[0];
    my $div  = $_[1];
    my $num = scalar(@{$aref});
    my @ar;
    
    if($num < $div){
	die "The number of sequences ($num) is less than $div.\n";
    }
    
    my @bin = getEachSize($num,$div);
    
    my $cum = 0;
    for(my $i = 0; $i <= $#bin; $i++){
	for(my $j = $cum; $j <= $cum + $bin[$i] - 1; $j++){
	    $ar[$i]{$aref->[$j]} = 0;
	}
	$cum += $bin[$i];
    }
    
    return @ar;
    
}

sub getEachSize_unif($$){
    # residual�������ʬ�䤹��С������
    my $num = $_[0];
    my $div = $_[1];
    
    my $size = int($num/$div);
    my $residual = $num - ($size * $div);

    my %add_res;
    if($residual > 0){
	my $cum = 0;
	my @res = getEachSize($div, $residual);
#	print STDERR "@res\n";
	for(my $r = 0; $r <= $#res; $r++){
	    $cum += $res[$r];
	    $add_res{$cum-1} = 1; # ���Υ��롼�פ�residual���ä����롣
	                          # ���롼�פ�0-based�ʤΤǡ�����˹�碌�롣
	}
    }
    
    my @bin;
    for(my $i = 0; $i < $div; $i++){
	if(defined $add_res{$i}){
	    $bin[$i] = $size + 1;
	    $residual--;
	}
	else{
	    $bin[$i] = $size;
	}
    }
    
    if($residual != 0){
	die "\$resudual should be zero here.\n";
    }
    
    return @bin;
    
}


sub getEachSizeEven($$){
    my $num = $_[0];
    my $div = $_[1];
    
    if($num %2 != 0){
	die "The number of elements is not even.\n";
    }
    
    $num /= 2;
    
    my $size = int($num/$div);
    my $residual = $num - ($size * $div);
    
    my @bin;
    for(my $i = 0; $i < $div; $i++){
	if($residual > 0){
	    $bin[$i] = $size + 1;
	    $residual--;
	}
	else{
	    $bin[$i] = $size;
	}
    }
    
    if($residual != 0){
	die "\$resudual should be zero here.\n";
    }
    
    foreach my $b (@bin){
	$b *= 2;
    }
    
    return @bin;
    
}

1;

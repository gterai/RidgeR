#!/usr/bin/perl -w

use strict;

unless($#ARGV == 2){
    die "usage: $0 [w.txt] [LenX] [LenY]\n";
}

my $LX = $ARGV[1];
my $LY = $ARGV[2];

my @W;
open(FH, $ARGV[0]) || die;
<FH>;
<FH>;
while(<FH>){
    chomp;
    
    my ($w, $val) = split /\t/;
    if($w !~ /^w(\d+)$/){
	die "Unexpected format of weights ($w)\n";
    }
    
    my $idx = $1;
    $W[$idx] = $val;
    
}
close(FH);

sub idx2ij{
    my ($ind, $r, $t) = @_;
    my $i = int($ind/$t); # 0-based
    my $j = ($ind % $t);  # 0-based

    return ($i, $j);
}

my (@wP, @wB, @wI, @wE);
for(my $idx = 0; $idx <= $#W; $idx++){
    
    if($idx < $LX * $LY){
	my ($i, $j) = idx2ij($idx, $LX, $LY);
	$wP[$i][$j] = $W[$idx];
    }
    else{
	my $idx2  = $idx - ($LX * $LY);
	if($idx2 % 3 == 0){
	    push(@wB, $W[$idx]);
	}
	elsif($idx2 % 3 == 1){
	    push(@wI, $W[$idx]);
	}
	elsif($idx2 % 3 == 2){
	    push(@wE, $W[$idx]);
	}
	else{
	    die "Unexpected quotient.\n";
	}
    }
}

# check length
if($#wB != $#wI){
    die "The length of wB and wI differ.\n";
} if($#wB != $#wE){
    die "The length of wB and wE differ.\n";
}

for(my $i = 0; $i <= $#wP; $i++){
    for(my $j = 0; $j <= $#{$wP[0]}; $j++){
	print "wP_$i\_$j\t$wP[$i][$j]\n";
    }
}

for(my $i = 0; $i <= $#wB; $i++){
    my $xy;
    if($i < $LY){   $xy = "y";    }    else{	$xy = "x";    }
    my $idx = $i;
    $idx -= $LY if($i >= $LY);    
    print "wB_$xy\_$idx\t$wB[$i]\n";
}
for(my $i = 0; $i <= $#wB; $i++){
    my $xy;
    if($i < $LY){   $xy = "y";    }    else{	$xy = "x";    }
    my $idx = $i;
    $idx -= $LY if($i >= $LY);    
    print "wI_$xy\_$idx\t$wI[$i]\n";
}
for(my $i = 0; $i <= $#wB; $i++){
    my $xy;
    if($i < $LY){   $xy = "y";    }    else{	$xy = "x";    }
    my $idx = $i;
    $idx -= $LY if($i >= $LY);    
    print "wE_$xy\_$idx\t$wE[$i]\n";
}

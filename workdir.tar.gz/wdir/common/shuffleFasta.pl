#!/usr/bin/perl -w

use strict;
#use File::Basename;
use FindBin;

my $ScriptDir = $FindBin::Bin;
#my $ScriptDir = my $BaseDir = dirname $0;

unless($#ARGV == 0){
    die "usage: $0 [*.fa]\n";
}

require "$ScriptDir/basic.pl";

my %seq = readSequence($ARGV[0]);
my @ids = keys %seq;

fisher_yates_shuffle(\@ids);

foreach my $id (@ids){
    print ">$id\n";
    print "$seq{$id}\n";
}

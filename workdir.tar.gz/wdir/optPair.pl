#!/usr/bin/perl -w

use strict;
use FileHandle;
use Getopt::Long;
use FindBin;

unless($#ARGV >= 1){
    die "usage: $0 [Alpha] [nCPU]\n";
    
}

my $BaseDir = $FindBin::Bin;

require "$BaseDir/common/basic.pl";

my ($D, $O, $F);
GetOptions('F'=>\$F, 'D=s'=>\$D, 'O=s'=>\$O);

my $DataDir = "$BaseDir/data/"; # これが味噌。Dokerではここがマウントポイントになる。
# 普段のスクリプトとしては、-D -Oを指定して使う。
# Dockerの時は、dataが入ったディレクトリを-vでマウント。-Oを使うこともできる。-Dは使ってはいけない。
# $BaseDirが/wdirの時には-Dを無効にした方が良いかも。
$DataDir = $D if(defined $D);

my $rnaX_file        = "$DataDir/seqX.fa";
my $train_file_org   = "$DataDir/seqY.fa";
my $id2exp_file_raw  = "$DataDir/act.txt";
my $OutDir           = "$DataDir/out"; $OutDir = "$DataDir/$O" if(defined $O);
my $Alp              = $ARGV[0];
my $id2PF_file       = "$OutDir/id2PF.txt";
my $wini_file        = "$OutDir/w_ini.txt";
my $id2prof_file     = "$OutDir/id2prof.txt";
my $nnfv_file        = "$OutDir/nnfv.txt";
my $wopt_file        = "$OutDir/w_opt.txt";
my $wfin_file        = "$OutDir/w_fin.txt";

# check input files
if(!-e $rnaX_file){
    die "seqX.fa was not found in the data directory.\n";
}
if(!-e $train_file_org){
    die "seqY.fa was not found in the data directory.\n";
}
if(!-e $id2exp_file_raw){
    die "act.txt was not found in the data directory.\n";
}

if($Alp <= 0){
    print STDERR "Alpha must be positive integer.\n";
    exit(0);
}

my $nCPU = &chkCPU($ARGV[1]);

# check workdir
if(-d $OutDir){
    # skip
}
else{
    `mkdir $OutDir`;
}

# check input data
my ($id_aref, $seq_aref) = &readSequenceArray_ref($train_file_org);
my ($rnaX_seq) = &readOneSeq($rnaX_file);
&chkLen($seq_aref);
my %id2exp_raw = &readHash($id2exp_file_raw);
&chkID($id_aref, \%id2exp_raw);

# get length of input RNA
my ($lX, $lY) = (length($rnaX_seq), length($seq_aref->[0]));

# make and read initial parameters
&makeWini($wini_file, length($rnaX_seq), length($seq_aref->[0]));

# calculate position specific-features for each training data
`perl $BaseDir/pair/calcCPF.pl $train_file_org $rnaX_file $wini_file $nCPU $id2PF_file $id2prof_file` if(!defined $F);

# create a table of feature vectors and normalized activity values
`python3 $BaseDir/pair/012makeDataNexp.py  $id2exp_file_raw $id2prof_file $lX $lY > $nnfv_file` if(!defined $F);

# run Ridge regression
`python3 $BaseDir/pair/runRidge.py $nnfv_file $Alp $wopt_file`;

# convert optimized weight
`perl $BaseDir/common/convWarray2W_pair.pl $wopt_file $lX $lY > $wfin_file`;


sub writeW{
    my ($w_file, $w_aref) = @_;
    my $ofh = new FileHandle(">$w_file") || die;
    print $ofh "wa\t$w_aref->[0]\n";
    print $ofh "wb\t$w_aref->[1]\n";
    for(my $i = 2; $i <= $#{$w_aref}; $i++){
	my $idx = $i - 2;
	print $ofh "w$idx\t$w_aref->[$i]\n";
    }
    $ofh->close();
}

sub chkCPU{
    my $n = $_[0];
    
    if($n =~ /[^\d]/){
	die "nCPU must be a positive integer.\n";
    }
    elsif($n < 1){
	die "nCPU must be a positive integer.\n";
    }
    elsif($n > 50){
	die "nCPU ($n) is too large.\n";
    }
    
    return $n;
}


sub createNexpFile{
    my $id2raw_href = $_[0];
    my $id_aref     = $_[1];
    my $nact_file   = $_[2];
    my ($min, $max) = (1e+100, -1e+100);
    foreach my $id (@{$id_aref}){
        my $val = $id2raw_href->{$id};
        $min = $val if($min > $val);
        $max = $val if($max < $val);
    }
    
    my $ofh = new FileHandle(">$nact_file") || die;
    foreach my $id (@{$id_aref}){
        my $val = $id2raw_href->{$id};
        my $nval = ($val - $min)/($max-$min);
        print $ofh "$id\t$nval\n";
    }
    $ofh->close();
    
}


sub readW{
    my %h;

    my $max_pos = -1;
    my $fh = new FileHandle($_[0]) || die "Can't open $_[0]:$!\n";
    while(<$fh>){
	chomp;

	if(/^D?(w[ab])/){
	    my $type = $1;
            my ($name, $val) = split /\t/;
            $h{$type} = $val;
	}
        elsif(/^D?w(\d+)/){
            my $pos = $1;
            my ($name, $val) = split /\t/;
            $h{wi}[$pos] = $val;
            $max_pos = $pos if($pos > $max_pos);
	}
        else{
            die "Unexpected line ($_)\n";
	}
    }
    $fh->close();

    $h{L} = $max_pos;

    return %h;

}


sub chkLen
{
    my $s_aref = $_[0];
    my $l = length($s_aref->[0]);
    for(my $i = 1; $i <= $#{$s_aref}; $i++){
        my $ll = length($s_aref->[$i]);
        if($l != $ll){
            die "Sequences with the different lengths were found.\n";
        }
    }
    # check ok
}

sub chkID{
    my ($i_aref, $i2e_href) = @_;
    foreach my $id (@{$i_aref}){
        if(!defined $i2e_href->{$id}){
            die "Activity value of $id is not defined.\n";
        }
    }

}

sub makeWini{
    my $ofh = new FileHandle(">$_[0]") || die "Can't create $wini_file:$!\n";
    my $R = $_[1];
    my $T = $_[2];
    print $ofh "wa\t0\n";
    print $ofh "wb\t1\n";

    my $H = 3;
    for(my $i = 0; $i < ($R * $T) + (($R + $T) * $H); $i++){
	print $ofh "w$i\t0\n";
    }
}




